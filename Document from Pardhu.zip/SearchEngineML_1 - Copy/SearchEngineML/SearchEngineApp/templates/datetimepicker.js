// Function to initialize the datetime picker
function initializeDateTimePicker() {
    // You would typically use a library like jQuery to select elements and attach event handlers
    // For this example, let's assume you have an input field with the id "datetimepicker"
    $('#datetimepicker').datetimepicker({
        format: 'YYYY-MM-DD HH:mm:ss', // Specify the format of the datetime
        // You can include more options as needed, such as minDate, maxDate, etc.
    });
}

// Call the initialization function when the document is ready
$(document).ready(function() {
    initializeDateTimePicker();
});
